namespace cpp ping
namespace py ping

service Ping
{
  void ping();
}

